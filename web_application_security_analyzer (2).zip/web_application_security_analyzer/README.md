# Web Application Security Analyzer

A small educational web application security assessment project built with:
- Python (standard library only)
- HTML
- CSS

No Flask, Django, Streamlit, database, JavaScript, or third-party Python packages are required.

## Features
- HTTPS check
- Selected HTTP security-header checks
- Basic Set-Cookie attribute review
- HTML form and password-field count
- Server-header observation
- Downloadable plain-text report

## Run
1. Install Python 3.
2. Open a terminal in this project folder.
3. Run:

   `python main.py`

4. Open `http://127.0.0.1:8000` in your browser.

## Important limitations
This is a basic, non-invasive checker. It does not exploit vulnerabilities, submit forms, authenticate, crawl an entire site, or prove that a vulnerability exists. Missing headers are observations that require context and manual validation. Test only websites you own or have explicit permission to assess.

The built-in server listens only on localhost. Keep it local and do not expose it to the public internet.

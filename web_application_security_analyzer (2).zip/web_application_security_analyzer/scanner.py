from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from urllib.parse import urlparse
from html.parser import HTMLParser
import ssl

class FormCounter(HTMLParser):
    def __init__(self):
        super().__init__()
        self.forms = 0
        self.password_fields = 0
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag.lower() == "form":
            self.forms += 1
        if tag.lower() == "input" and attrs.get("type", "").lower() == "password":
            self.password_fields += 1

def scan_website(target):
    if not target:
        raise ValueError("Enter a website URL.")
    if "://" not in target:
        target = "https://" + target

    parsed = urlparse(target)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("Use a valid http:// or https:// URL.")
    if parsed.username or parsed.password:
        raise ValueError("URLs containing embedded usernames or passwords are not accepted.")

    request = Request(target, headers={"User-Agent": "Simple-Web-Security-Analyzer/1.0"})
    try:
        context = ssl.create_default_context()
        with urlopen(request, timeout=10, context=context) as response:
            final_url = response.geturl()
            status = response.status
            headers = response.headers
            body = response.read(1_000_000).decode("utf-8", errors="replace")
    except HTTPError as error:
        final_url = error.geturl()
        status = error.code
        headers = error.headers
        body = error.read(1_000_000).decode("utf-8", errors="replace")
    except (URLError, TimeoutError, ssl.SSLError, ValueError) as error:
        raise ValueError(f"Could not connect to the target: {error}")

    final_scheme = urlparse(final_url).scheme
    findings = []

    def add(check, severity, result, recommendation):
        findings.append({"check": check, "severity": severity,
                         "result": result, "recommendation": recommendation})

    if final_scheme == "https":
        add("HTTPS", "Info", "The final page URL uses HTTPS.",
            "Continue using HTTPS and keep the TLS certificate configuration up to date.")
    else:
        add("HTTPS", "High", "The final page URL uses HTTP rather than HTTPS.",
            "Configure HTTPS and redirect HTTP traffic to HTTPS.")

    add("HTTP response", "Info", f"Server returned HTTP status {status}.",
        "Review unexpected status codes and ensure error pages do not expose sensitive details.")

    header_checks = {
        "Content-Security-Policy": ("Medium", "Define a suitable Content-Security-Policy to reduce script and content injection risks."),
        "Strict-Transport-Security": ("Medium", "Enable HSTS on HTTPS sites after confirming HTTPS works across the domain."),
        "X-Content-Type-Options": ("Low", "Set X-Content-Type-Options: nosniff."),
        "X-Frame-Options": ("Low", "Set an appropriate frame policy, or use frame-ancestors in CSP."),
        "Referrer-Policy": ("Low", "Set a Referrer-Policy appropriate for the application."),
    }
    for name, (severity, fix) in header_checks.items():
        if headers.get(name):
            add(name, "Info", f"Header is present: {headers.get(name)}", "Review the value to ensure it matches the application's security policy.")
        else:
            add(name, severity, "Header was not observed in the HTTP response.",
                fix)

    cookies = headers.get_all("Set-Cookie") or []
    if not cookies:
        add("Cookie security", "Info", "No Set-Cookie header was observed in this response.",
            "If the application uses session cookies, verify their security attributes on authenticated pages.")
    else:
        for index, cookie in enumerate(cookies, 1):
            lower = cookie.lower()
            missing = []
            if final_scheme == "https" and "secure" not in lower:
                missing.append("Secure")
            if "httponly" not in lower:
                missing.append("HttpOnly")
            if "samesite" not in lower:
                missing.append("SameSite")
            if missing:
                add(f"Cookie #{index} attributes", "Medium",
                    "Cookie response appears to be missing: " + ", ".join(missing) + ".",
                    "Set appropriate Secure, HttpOnly and SameSite attributes where applicable.")
            else:
                add(f"Cookie #{index} attributes", "Info",
                    "Secure, HttpOnly and SameSite attributes were observed.",
                    "Confirm cookie scope, lifetime and SameSite policy are appropriate.")

    parser = FormCounter()
    try:
        parser.feed(body)
    except Exception:
        pass
    add("HTML forms", "Info",
        f"Found {parser.forms} form(s) and {parser.password_fields} password field(s) in the retrieved page.",
        "Review server-side validation, CSRF protection and authentication controls manually. This scanner does not submit forms.")

    server = headers.get("Server")
    if server:
        add("Server banner", "Low", f"Server header is exposed: {server}.",
            "Consider minimizing unnecessary software/version disclosure in response headers.")
    else:
        add("Server banner", "Info", "No Server header was observed.",
            "Continue limiting unnecessary technology disclosure.")

    return {"url": final_url, "findings": findings}

def make_report(data):
    lines = [
        "WEB APPLICATION SECURITY ASSESSMENT",
        "=" * 38,
        f"Target: {data['url']}",
        f"Total checks: {len(data['findings'])}",
        "",
        "IMPORTANT: This is a basic, non-invasive assessment. It does not prove exploitability.",
        "Only test systems you own or have explicit permission to assess.",
        "",
        "FINDINGS",
        "-" * 38,
    ]
    for item in data["findings"]:
        lines.extend([
            f"\n[{item['severity']}] {item['check']}",
            f"Observation: {item['result']}",
            f"Recommendation: {item['recommendation']}",
        ])
    return "\n".join(lines)

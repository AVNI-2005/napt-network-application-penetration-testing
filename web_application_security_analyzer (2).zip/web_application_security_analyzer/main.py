from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse
from html import escape
import secrets

from scanner import scan_website, make_report

HOST = "127.0.0.1"
PORT = 8000
REPORTS = {}

def read_file(path):
    return (base_dir / path).read_text(encoding="utf-8")

base_dir = __import__("pathlib").Path(__file__).resolve().parent

class SecurityAnalyzerHandler(BaseHTTPRequestHandler):
    def send_page(self, content, status=200, content_type="text/html; charset=utf-8"):
        data = content.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = urlparse(self.path).path

        if path == "/":
            page = read_file("templates/index.html")
            self.send_page(page)
        elif path == "/style.css":
            self.send_page(read_file("static/style.css"), content_type="text/css; charset=utf-8")
        elif path.startswith("/report/"):
            report_id = path.rsplit("/", 1)[-1]
            report = REPORTS.get(report_id)
            if not report:
                self.send_page("Report not found. Run a new scan.", 404, "text/plain; charset=utf-8")
                return
            data = report.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="web_security_report.txt"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        else:
            self.send_page("Page not found.", 404)

    def do_POST(self):
        if urlparse(self.path).path != "/scan":
            self.send_page("Page not found.", 404)
            return

        length = int(self.headers.get("Content-Length", "0"))
        if length > 10000:
            self.send_page("Request too large.", 413)
            return

        form = parse_qs(self.rfile.read(length).decode("utf-8", errors="replace"))
        target = form.get("url", [""])[0].strip()
        consent = form.get("authorized", [""])[0]

        if consent != "yes":
            self.send_page("<h2>Authorization required</h2><p>Please confirm that you own the target or have permission to test it.</p><p><a href='/'>Go back</a></p>", 400)
            return

        try:
            results = scan_website(target)
            report = make_report(results)
            report_id = secrets.token_urlsafe(12)
            REPORTS[report_id] = report
            self.send_page(render_results(results, report_id))
        except ValueError as error:
            self.send_page(error_page(str(error)), 400)
        except Exception as error:
            self.send_page(error_page("The scan could not be completed: " + str(error)), 500)

def error_page(message):
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>Scan error</title>
    <link rel="stylesheet" href="/style.css"></head><body><main class="container">
    <section class="panel"><h1>Scan could not be completed</h1><p>{escape(message)}</p>
    <a class="button secondary" href="/">Return to scanner</a></section></main></body></html>"""

def render_results(data, report_id):
    findings = data["findings"]
    rows = ""
    for item in findings:
        rows += f"""<tr><td>{escape(item['check'])}</td>
        <td><span class="severity {escape(item['severity'].lower())}">{escape(item['severity'])}</span></td>
        <td>{escape(item['result'])}</td><td>{escape(item['recommendation'])}</td></tr>"""

    counts = {level: sum(1 for item in findings if item["severity"] == level)
              for level in ("High", "Medium", "Low", "Info")}
    return f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Security Scan Results</title><link rel="stylesheet" href="/style.css"></head><body>
    <header class="topbar"><div class="brand">WEB<span>SEC</span> ANALYZER</div><a href="/">New scan</a></header>
    <main class="container"><section class="page-heading"><p class="eyebrow">ASSESSMENT COMPLETE</p>
    <h1>Security scan results</h1><p class="muted">Target: <strong>{escape(data['url'])}</strong></p></section>
    <section class="stats">
      <div class="stat"><small>Total checks</small><strong>{len(findings)}</strong></div>
      <div class="stat"><small>High</small><strong class="high-text">{counts['High']}</strong></div>
      <div class="stat"><small>Medium</small><strong class="medium-text">{counts['Medium']}</strong></div>
      <div class="stat"><small>Low / Info</small><strong>{counts['Low'] + counts['Info']}</strong></div>
    </section>
    <section class="panel"><div class="panel-title"><div><p class="eyebrow">FINDINGS</p><h2>Assessment details</h2></div>
    <a class="button" href="/report/{report_id}">Download report</a></div>
    <div class="table-wrap"><table><thead><tr><th>Security check</th><th>Severity</th><th>Observation</th><th>Recommendation</th></tr></thead>
    <tbody>{rows}</tbody></table></div></section>
    <p class="footnote">This is a basic, non-invasive assessment. Findings are indicators, not proof of exploitability. Manually validate before drawing conclusions.</p>
    <a class="button secondary" href="/">Run another scan</a></main></body></html>"""

if __name__ == "__main__":
    print(f"Web Security Analyzer running at http://{HOST}:{PORT}")
    print("Press Ctrl+C to stop.")
    HTTPServer((HOST, PORT), SecurityAnalyzerHandler).serve_forever()

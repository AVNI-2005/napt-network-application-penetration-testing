NAPT - Network & Application Penetration Testing (Mini Project)
Only ONE code file: app.py (Python + HTML + CSS inside). No install needed.

RUN:
  Windows:  python app.py      (or: py app.py)
  Linux/Mac: python3 app.py
Browser opens automatically at http://the address printed in the terminal (usually http://127.0.0.1:8765)
Stop with Ctrl+C.

Scan only your own systems or ones you have written permission to test.
Safe targets: 127.0.0.1, scanme.nmap.org, testphp.vulnweb.com

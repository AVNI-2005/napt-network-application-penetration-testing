"""
NAPT - Network & Application Penetration Testing (Mini Project)
SINGLE FILE: Python + HTML + CSS together. Standard library only.
Run:  python app.py      (browser opens automatically)
Use only on systems you own or have written permission to test.
"""
import html, os, uuid
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs
import socket, ssl, re, time, datetime, http.client, urllib.parse
from concurrent.futures import ThreadPoolExecutor

# port -> (service, severity if open, advice)
PORT_INFO = {
    21:   ("FTP", "High", "FTP sends passwords in clear text. Use SFTP/FTPS or close the port."),
    22:   ("SSH", "Low", "Use key-based login, disable root login, restrict by IP."),
    23:   ("Telnet", "High", "Telnet is unencrypted. Disable it and use SSH."),
    25:   ("SMTP", "Medium", "Make sure it is not an open relay and requires authentication."),
    53:   ("DNS", "Low", "Disable recursion for outside users and restrict zone transfers."),
    80:   ("HTTP", "Low", "Redirect all traffic to HTTPS."),
    110:  ("POP3", "Medium", "Use POP3S (995) instead of clear-text POP3."),
    111:  ("RPCbind", "Medium", "Block from the internet; not needed publicly."),
    135:  ("MS-RPC", "High", "Block at firewall; commonly abused on Windows."),
    139:  ("NetBIOS", "High", "Block at firewall; legacy file sharing."),
    143:  ("IMAP", "Medium", "Use IMAPS (993) instead of clear-text IMAP."),
    443:  ("HTTPS", "Info", "Keep TLS configuration modern (TLS 1.2+)."),
    445:  ("SMB", "High", "Block from the internet; patch regularly."),
    993:  ("IMAPS", "Info", "Encrypted mail access."),
    995:  ("POP3S", "Info", "Encrypted mail access."),
    1433: ("MSSQL", "High", "Databases must not be exposed publicly. Restrict to app servers."),
    1521: ("Oracle DB", "High", "Databases must not be exposed publicly."),
    3306: ("MySQL", "High", "Databases must not be exposed publicly. Bind to localhost."),
    3389: ("RDP", "High", "Use VPN, enable NLA, restrict by IP."),
    5432: ("PostgreSQL", "High", "Databases must not be exposed publicly."),
    5900: ("VNC", "High", "Use VPN/SSH tunnel; set strong password."),
    6379: ("Redis", "High", "Redis has no auth by default. Bind to localhost, set password."),
    8000: ("HTTP-alt", "Low", "Check this is an intended public service."),
    8080: ("HTTP-proxy/alt", "Low", "Check this is an intended public service."),
    8443: ("HTTPS-alt", "Info", "Check TLS configuration."),
    27017:("MongoDB", "High", "Enable authentication and do not expose publicly."),
}
COMMON_PORTS = sorted(PORT_INFO)

SEV_ORDER = {"High": 0, "Medium": 1, "Low": 2, "Info": 3}
SEV_POINTS = {"High": 15, "Medium": 8, "Low": 3, "Info": 0}


def parse_ports(text, mode):
    if mode == "common":
        return COMMON_PORTS
    ports = set()
    for part in text.replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            a, b = int(a), int(b)
            ports.update(range(max(1, a), min(65535, b) + 1))
        else:
            p = int(part)
            if 1 <= p <= 65535:
                ports.add(p)
    ports = sorted(ports)
    if len(ports) > 2000:
        raise ValueError("Too many ports. Maximum is 2000 per scan.")
    if not ports:
        raise ValueError("No valid ports given.")
    return ports


def clean_target(raw):
    """Return (host, url) from user input like example.com or http://x.com/path"""
    raw = raw.strip()
    if not re.match(r"^https?://", raw, re.I):
        raw = "http://" + raw
    u = urllib.parse.urlparse(raw)
    if not u.hostname:
        raise ValueError("Invalid target.")
    return u.hostname, raw


# ---------------------------------------------------------------- NETWORK
def _scan_port(args):
    host, port, timeout = args
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        if s.connect_ex((host, port)) != 0:
            return None
        banner = ""
        try:
            if port in (80, 8000, 8080, 8443, 443):
                if port in (443, 8443):
                    return {"port": port, "banner": "(TLS service)"}
                s.sendall(b"HEAD / HTTP/1.0\r\n\r\n")
            s.settimeout(1.0)
            banner = s.recv(200).decode("latin-1", "ignore").strip().splitlines()
            banner = banner[0][:120] if banner else ""
        except Exception:
            banner = ""
        return {"port": port, "banner": banner}
    except Exception:
        return None
    finally:
        s.close()


def network_scan(ip, ports, timeout=0.8):
    with ThreadPoolExecutor(max_workers=100) as ex:
        res = [r for r in ex.map(_scan_port, [(ip, p, timeout) for p in ports]) if r]
    open_ports, findings = [], []
    for r in sorted(res, key=lambda x: x["port"]):
        p = r["port"]
        try:
            name = PORT_INFO[p][0] if p in PORT_INFO else socket.getservbyport(p)
        except Exception:
            name = "unknown"
        sev, advice = (PORT_INFO[p][1], PORT_INFO[p][2]) if p in PORT_INFO else (
            "Low", "Unknown service. Close it if it is not required.")
        open_ports.append({"port": p, "service": name, "banner": r["banner"], "severity": sev})
        findings.append({
            "category": "Network", "severity": sev,
            "title": f"Open port {p}/tcp ({name})",
            "detail": ("Banner: " + r["banner"]) if r["banner"] else "Port accepts TCP connections.",
            "fix": advice})
    return open_ports, findings


# ---------------------------------------------------------------- WEB / APPLICATION
def _request(host, port, https, method, path, timeout=6):
    if https:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        conn = http.client.HTTPSConnection(host, port, timeout=timeout, context=ctx)
    else:
        conn = http.client.HTTPConnection(host, port, timeout=timeout)
    try:
        conn.request(method, path, headers={"User-Agent": "NAPT-Student-Scanner/1.0", "Connection": "close"})
        r = conn.getresponse()
        body = r.read(60000).decode("latin-1", "ignore") if method != "HEAD" else ""
        return r.status, r.getheaders(), body
    finally:
        conn.close()


def web_scan(url):
    f = []
    u = urllib.parse.urlparse(url)
    https = u.scheme == "https"
    host = u.hostname
    port = u.port or (443 if https else 80)
    path = u.path or "/"
    try:
        status, hdrs, body = _request(host, port, https, "GET", path)
    except Exception as e:
        return [{"category": "Application", "severity": "Info", "title": "Web server not reachable",
                 "detail": f"Could not fetch {url}: {e}", "fix": "Check the URL/port and that the server is running."}]
    H = {}
    for k, v in hdrs:
        H.setdefault(k.lower(), []).append(v)
    one = lambda k: H.get(k, [""])[0]

    f.append({"category": "Application", "severity": "Info", "title": f"HTTP response status {status}",
              "detail": f"Fetched {url}", "fix": "-"})

    if not https:
        f.append({"category": "Application", "severity": "Medium", "title": "Site tested over plain HTTP",
                  "detail": "Traffic can be read or modified by anyone on the network.",
                  "fix": "Install a TLS certificate and redirect HTTP to HTTPS."})

    checks = [
        ("content-security-policy", "Medium", "Missing Content-Security-Policy",
         "CSP reduces the impact of XSS attacks.", "Add a Content-Security-Policy header."),
        ("x-content-type-options", "Low", "Missing X-Content-Type-Options",
         "Browsers may MIME-sniff responses.", "Add 'X-Content-Type-Options: nosniff'."),
        ("referrer-policy", "Low", "Missing Referrer-Policy",
         "URLs may leak to other sites.", "Add 'Referrer-Policy: strict-origin-when-cross-origin'."),
        ("permissions-policy", "Low", "Missing Permissions-Policy",
         "Browser features are not restricted.", "Add a Permissions-Policy header."),
    ]
    for h, sev, title, det, fix in checks:
        if h not in H:
            f.append({"category": "Application", "severity": sev, "title": title, "detail": det, "fix": fix})
    if "x-frame-options" not in H and "frame-ancestors" not in one("content-security-policy"):
        f.append({"category": "Application", "severity": "Medium", "title": "Clickjacking protection missing",
                  "detail": "No X-Frame-Options or CSP frame-ancestors.",
                  "fix": "Add 'X-Frame-Options: DENY' or CSP frame-ancestors."})
    if https and "strict-transport-security" not in H:
        f.append({"category": "Application", "severity": "Medium", "title": "Missing HSTS header",
                  "detail": "Browsers are not forced to use HTTPS.", "fix": "Add Strict-Transport-Security header."})

    # information disclosure
    for h in ("server", "x-powered-by", "x-aspnet-version"):
        v = one(h)
        if v and (h != "server" or re.search(r"\d", v)):
            f.append({"category": "Application", "severity": "Low", "title": f"Technology disclosure: {h}: {v}",
                      "detail": "Version details help attackers pick known exploits.",
                      "fix": "Hide or generalise this header in server configuration."})

    # cookies
    for c in H.get("set-cookie", []):
        name = c.split("=", 1)[0]
        low = c.lower()
        miss = []
        if https and "secure" not in low: miss.append("Secure")
        if "httponly" not in low: miss.append("HttpOnly")
        if "samesite" not in low: miss.append("SameSite")
        if miss:
            f.append({"category": "Application", "severity": "Medium", "title": f"Cookie '{name}' missing flags",
                      "detail": "Missing: " + ", ".join(miss), "fix": "Set Secure; HttpOnly; SameSite on cookies."})

    # page content checks
    if re.search(r"<input[^>]+type=[\"']?password", body, re.I) and not https:
        f.append({"category": "Application", "severity": "High", "title": "Password form on non-HTTPS page",
                  "detail": "Passwords will travel in clear text.", "fix": "Serve login pages only over HTTPS."})
    if re.search(r"<form", body, re.I) and not re.search(r"csrf|token|authenticity", body, re.I):
        f.append({"category": "Application", "severity": "Low", "title": "Form without visible anti-CSRF token",
                  "detail": "Forms may be vulnerable to Cross-Site Request Forgery.",
                  "fix": "Add per-session CSRF tokens to state-changing forms."})
    if "index of /" in body.lower():
        f.append({"category": "Application", "severity": "Medium", "title": "Directory listing enabled",
                  "detail": "Folder contents are visible.", "fix": "Disable directory indexing."})

    # HTTP methods
    try:
        st, h2, _ = _request(host, port, https, "OPTIONS", path)
        allow = ",".join(v for k, v in h2 if k.lower() == "allow").upper()
        bad = [m for m in ("TRACE", "PUT", "DELETE", "CONNECT") if m in allow]
        if bad:
            f.append({"category": "Application", "severity": "Medium", "title": "Risky HTTP methods allowed",
                      "detail": "Allow: " + allow, "fix": "Disable " + ", ".join(bad) + " unless required."})
    except Exception:
        pass

    # sensitive files (simple GET requests, no exploitation)
    sensitive = [("/.git/HEAD", "High", "ref:"), ("/.env", "High", "="), ("/phpinfo.php", "Medium", "phpinfo"),
                 ("/backup.zip", "High", None), ("/admin", "Low", None), ("/server-status", "Medium", "apache"),
                 ("/robots.txt", "Info", "disallow")]
    for p, sev, marker in sensitive:
        try:
            st, h3, b3 = _request(host, port, https, "GET", p, timeout=4)
            if st == 200 and (marker is None or marker in b3.lower()):
                if p == "/backup.zip" and "html" in ",".join(v for k, v in h3 if k.lower() == "content-type").lower():
                    continue
                f.append({"category": "Application", "severity": sev, "title": f"Exposed path: {p}",
                          "detail": "Returned HTTP 200.",
                          "fix": "Remove the file or restrict access." if sev != "Info" else "Make sure it lists nothing sensitive."})
        except Exception:
            pass

    # TLS
    if https or port == 443:
        f += tls_check(host, 443 if not https else port)
    return f


def tls_check(host, port):
    out = []
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=6) as s:
            with ctx.wrap_socket(s, server_hostname=host) as ss:
                cert = ss.getpeercert()
                ver = ss.version()
        exp = datetime.datetime.fromtimestamp(ssl.cert_time_to_seconds(cert["notAfter"]), datetime.timezone.utc).replace(tzinfo=None)
        days = (exp - datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)).days
        sev = "High" if days < 0 else "Medium" if days < 15 else "Info"
        out.append({"category": "TLS", "severity": sev, "title": f"Certificate expires in {days} days",
                    "detail": f"Valid until {exp:%Y-%m-%d}, protocol {ver}.", "fix": "Renew certificate before expiry."})
    except ssl.SSLCertVerificationError as e:
        out.append({"category": "TLS", "severity": "High", "title": "Certificate not trusted",
                    "detail": str(e.reason if hasattr(e, 'reason') else e), "fix": "Install a valid certificate from a trusted CA."})
    except Exception as e:
        out.append({"category": "TLS", "severity": "Info", "title": "TLS check not possible",
                    "detail": str(e), "fix": "-"})
    return out


# ---------------------------------------------------------------- MAIN
def run_scan(target, scan_type, port_mode, port_text):
    host, url = clean_target(target)
    ip = socket.gethostbyname(host)
    start = time.time()
    ports_open, findings = [], []
    if scan_type in ("network", "both"):
        ports = parse_ports(port_text, port_mode)
        ports_open, nf = network_scan(ip, ports)
        findings += nf
    if scan_type in ("web", "both"):
        findings += web_scan(url)
    findings.sort(key=lambda x: SEV_ORDER[x["severity"]])
    score = max(0, 100 - sum(SEV_POINTS[x["severity"]] for x in findings))
    counts = {s: sum(1 for x in findings if x["severity"] == s) for s in SEV_ORDER}
    return {"target": host, "url": url, "ip": ip, "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "duration": round(time.time() - start, 1), "ports": ports_open, "findings": findings,
            "score": score, "counts": counts, "scan_type": scan_type}


def text_report(r):
    L = ["NAPT - Network & Application Penetration Testing Report", "=" * 55,
         f"Target   : {r['target']} ({r['ip']})", f"Date     : {r['time']}",
         f"Duration : {r['duration']} s", f"Score    : {r['score']}/100",
         "Summary  : " + ", ".join(f"{k}={v}" for k, v in r["counts"].items()), ""]
    if r["ports"]:
        L.append("OPEN PORTS"); L.append("-" * 55)
        for p in r["ports"]:
            L.append(f"{p['port']:<6}{p['service']:<16}{p['banner']}")
        L.append("")
    L.append("FINDINGS"); L.append("-" * 55)
    for i, x in enumerate(r["findings"], 1):
        L += [f"{i}. [{x['severity']}] {x['title']}  ({x['category']})",
              f"   Detail : {x['detail']}", f"   Fix    : {x['fix']}", ""]
    L.append("Only test systems you own or have written permission to test.")
    return "\n".join(L)


# ======================= WEB PAGE (HTML + CSS) =======================
INDEX_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NAPT - Network &amp; Application Penetration Testing</title>
<style>
*{box-sizing:border-box}
body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#0f172a;color:#e2e8f0}
header{text-align:center;padding:28px 10px;background:linear-gradient(135deg,#1e3a8a,#0e7490)}
header h1{margin:0;font-size:2.2rem;letter-spacing:3px}
header p{margin:6px 0 0;opacity:.85}
main{max-width:900px;margin:24px auto;padding:0 14px}
.card{background:#1e293b;border-radius:12px;padding:22px;margin-bottom:22px;box-shadow:0 4px 14px rgba(0,0,0,.35)}
h2,h3{margin-top:0}
label{display:block;margin:14px 0 6px;font-weight:600;font-size:.9rem}
input[type=text],select{width:100%;padding:10px;border-radius:8px;border:1px solid #475569;background:#0f172a;color:#e2e8f0;font-size:1rem}
.row{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px}
.check{display:flex;gap:10px;align-items:center;font-weight:400}
button,.btn{display:inline-block;margin-top:16px;padding:12px 28px;background:#06b6d4;color:#042f3a;border:0;border-radius:8px;font-weight:700;font-size:1rem;cursor:pointer;text-decoration:none}
button:hover,.btn:hover{background:#22d3ee}
.error{background:#7f1d1d;padding:10px 14px;border-radius:8px;margin-bottom:10px}
.muted{opacity:.65;font-size:.85rem}
.summary{display:flex;gap:24px;align-items:center;flex-wrap:wrap}
.score{font-size:3rem;font-weight:800;width:120px;height:120px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:6px solid}
.score span{font-size:1rem;opacity:.7}
.score.good{border-color:#22c55e;color:#22c55e}.score.warn{border-color:#f59e0b;color:#f59e0b}.score.bad{border-color:#ef4444;color:#ef4444}
.badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:.78rem;font-weight:700;color:#fff;margin-right:6px}
.badge.High{background:#dc2626}.badge.Medium{background:#d97706}.badge.Low{background:#2563eb}.badge.Info{background:#64748b}
.tablewrap{overflow-x:auto}
table{width:100%;border-collapse:collapse}
th,td{padding:8px 10px;text-align:left;border-bottom:1px solid #334155;font-size:.92rem}
th{background:#0f172a}
.finding{border-left:5px solid;background:#0f172a;padding:10px 14px;margin:10px 0;border-radius:6px}
.finding.High{border-color:#dc2626}.finding.Medium{border-color:#d97706}.finding.Low{border-color:#2563eb}.finding.Info{border-color:#64748b}
.fhead{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.fhead em{margin-left:auto;opacity:.6;font-size:.8rem}
.finding p{margin:6px 0 0;font-size:.9rem}
.fix{color:#86efac}
.info li{margin:6px 0}
footer{text-align:center;padding:18px;opacity:.6;font-size:.85rem}

</style>
</head>
<body>
<header>
  <h1>&#128737; NAPT</h1>
  <p>Network &amp; Application Penetration Testing &mdash; Mini Project</p>
</header>
<main>
  <section class="card">
    <h2>New Assessment</h2>
    {{error}}
    <form method="POST" action="/scan">
      <label>Target (domain, IP, or URL)</label>
      <input type="text" name="target" value="{{target}}" placeholder="e.g. 127.0.0.1 or http://testphp.vulnweb.com" required>

      <div class="row">
        <div>
          <label>Scan Type</label>
          <select name="scan_type">
            <option value="both" {{sel_both}}>Network + Application</option>
            <option value="network" {{sel_network}}>Network only (ports)</option>
            <option value="web" {{sel_web}}>Application only (web)</option>
          </select>
        </div>
        <div>
          <label>Port Selection</label>
          <select name="port_mode">
            <option value="common">Common ports (26)</option>
            <option value="custom">Custom range</option>
          </select>
        </div>
        <div>
          <label>Custom ports</label>
          <input type="text" name="ports" value="1-1024" placeholder="1-1024 or 22,80,443">
        </div>
      </div>

      <label class="check">
        <input type="checkbox" name="consent" value="1">
        I own this target or have written permission to test it.
      </label>
      <button type="submit">Start Scan</button>
    </form>
  </section>

  {{results}}

  <section class="card info">
    <h3>What this tool does</h3>
    <ul>
      <li><b>Network testing:</b> TCP port scan, service identification, banner grabbing, risky-service detection.</li>
      <li><b>Application testing:</b> security headers, cookie flags, information disclosure, risky HTTP methods, exposed files, directory listing, TLS certificate check.</li>
      <li><b>Report:</b> security score, severity ratings, fixes, downloadable text report.</li>
    </ul>
    <p class="muted">Safe test targets: your own PC (127.0.0.1), scanme.nmap.org, testphp.vulnweb.com.</p>
  </section>
</main>
<footer>NAPT Mini Project &bull; Python + HTML + CSS &bull; For educational use only</footer>
</body>
</html>
"""

# ======================= WEB SERVER =======================
REPORTS = {}  # id -> text report (kept in memory)

REPORTS = {}  # id -> text report (kept in memory)


def esc(x):
    return html.escape(str(x))


def render_results(r):
    c = r["counts"]
    cls = "good" if r["score"] >= 80 else "warn" if r["score"] >= 50 else "bad"
    out = [f'<section class="card"><h2>Scan Result: {esc(r["target"])} <small>({esc(r["ip"])})</small></h2>',
           f'<div class="summary"><div class="score {cls}">{r["score"]}<span>/100</span></div><div class="badges">']
    for s in ("High", "Medium", "Low", "Info"):
        out.append(f'<span class="badge {s}">{s}: {c[s]}</span>')
    out.append(f'</div></div><p class="muted">Scanned at {esc(r["time"])} in {r["duration"]}s</p>')
    if r["ports"]:
        out.append('<h3>Open Ports</h3><div class="tablewrap"><table><tr><th>Port</th><th>Service</th><th>Risk</th><th>Banner</th></tr>')
        for p in r["ports"]:
            out.append(f'<tr><td>{p["port"]}</td><td>{esc(p["service"])}</td>'
                       f'<td><span class="badge {p["severity"]}">{p["severity"]}</span></td><td>{esc(p["banner"])}</td></tr>')
        out.append('</table></div>')
    elif r["scan_type"] in ("network", "both"):
        out.append('<p>No open ports found in the scanned range.</p>')
    out.append('<h3>Findings &amp; Recommendations</h3>')
    for x in r["findings"]:
        out.append(f'<div class="finding {x["severity"]}"><div class="fhead"><span class="badge {x["severity"]}">{x["severity"]}</span>'
                   f'<b>{esc(x["title"])}</b><em>{esc(x["category"])}</em></div>'
                   f'<p>{esc(x["detail"])}</p><p class="fix"><b>Fix:</b> {esc(x["fix"])}</p></div>')
    out.append(f'<a class="btn" href="/report/{r["id"]}">Download Report (.txt)</a></section>')
    return "\n".join(out)


def page(results="", error="", target="", scan_type="both"):
    t = INDEX_HTML
    t = t.replace("{{results}}", results).replace("{{target}}", esc(target))
    t = t.replace("{{error}}", f'<div class="error">{esc(error)}</div>' if error else "")
    for k in ("network", "web", "both"):
        t = t.replace("{{sel_%s}}" % k, "selected" if k == scan_type else "")
    return t.encode()


class Server(ThreadingHTTPServer):
    allow_reuse_address = False   # on Windows True lets two programs share one port (causes empty response)
    daemon_threads = True


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def handle_one_request(self):
        try:
            super().handle_one_request()
        except (ConnectionError, TimeoutError):
            pass
        except Exception:
            import traceback
            traceback.print_exc()
            try:
                self.send(b"Internal error - see the terminal for details.", "text/plain", 500)
            except Exception:
                pass

    def send(self, body, ctype="text/html; charset=utf-8", code=200, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/":
            self.send(page())
        elif self.path.startswith("/report/") and self.path[8:] in REPORTS:
            self.send(REPORTS[self.path[8:]].encode(), "text/plain; charset=utf-8",
                      extra={"Content-Disposition": "attachment; filename=napt_report.txt"})
        else:
            self.send(b"Not found", "text/plain", 404)

    def do_POST(self):
        if self.path != "/scan":
            return self.send(b"Not found", "text/plain", 404)
        n = int(self.headers.get("Content-Length", 0))
        form = {k: v[0] for k, v in parse_qs(self.rfile.read(min(n, 5000)).decode()).items()}
        target = form.get("target", "").strip()
        stype = form.get("scan_type", "both")
        if stype not in ("network", "web", "both"):
            stype = "both"
        if not form.get("consent"):
            return self.send(page(error="You must confirm you have permission to test this target.", target=target, scan_type=stype))
        try:
            r = run_scan(target, stype, form.get("port_mode", "common"), form.get("ports", "1-1024"))
            r["id"] = uuid.uuid4().hex[:12]
            REPORTS[r["id"]] = text_report(r)
            self.send(page(render_results(r), target=target, scan_type=stype))
        except Exception as e:
            self.send(page(error=f"Scan failed: {e}", target=target, scan_type=stype))

    def log_message(self, fmt, *a):
        print("[%s] %s" % (self.address_string(), fmt % a))


def main():
    import webbrowser
    for port in range(8765, 8775):
        try:
            server = Server(("127.0.0.1", port), Handler)
            break
        except OSError:
            continue
    else:
        print("No free port found (8765-8774). Close other programs and retry.")
        return
    url = f"http://127.0.0.1:{port}"
    print(f"NAPT running at {url}  (press Ctrl+C to stop)")
    try:
        webbrowser.open(url)
    except Exception:
        pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Stopped.")


if __name__ == "__main__":
    main()
